import sys, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'runs/c001_tiled_128x128x64/solution'))
import torch
from reference import make_inputs
from kernel import _gemm
x = make_inputs(seed=17)
y = torch.empty((4096,4096),dtype=torch.bfloat16,device='cuda')
k = _gemm[(1024,)](x['x'], x['weight'], y,4096,4096,4096,128,128,64,8,num_warps=4,num_stages=3)
p = Path(__file__).resolve().parents[1] / 'analysis'
(p/'metadata.json').write_text(json.dumps({'metadata': k.metadata._asdict(), 'n_regs':k.n_regs, 'n_spills':k.n_spills},indent=2,default=str))
for name in ['ptx', 'ttgir', 'llir']:
    (p/f'kernel.{name}').write_text(k.asm[name])
(p/'kernel.cubin').write_bytes(k.asm['cubin'])
print((p/'metadata.json').read_text())
