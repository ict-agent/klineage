import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'runs/c001_tiled_128x128x64/solution'))
import torch
from reference import make_inputs
from kernel import kernel
inputs = make_inputs(seed=17)
for _ in range(3):
    result = kernel(**inputs)
    torch.cuda.synchronize()
