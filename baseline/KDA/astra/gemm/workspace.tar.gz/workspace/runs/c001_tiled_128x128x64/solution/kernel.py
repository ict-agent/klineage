"""Custom BF16 GEMM for contiguous row-major X and transposed weights."""

import json
from pathlib import Path

import torch
import triton as tr
import triton.language as tl

_CFG = json.loads(Path(__file__).with_name("config.json").read_text())


@tr.jit
def _gemm(X, W, Y, M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
          BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
          GROUP: tl.constexpr):
    pid = tl.program_id(0)
    nm = tl.cdiv(M, BM)
    nn = tl.cdiv(N, BN)
    group = pid // (GROUP * nn)
    first_m = group * GROUP
    group_m = tl.minimum(nm - first_m, GROUP)
    pm = first_m + (pid % (GROUP * nn)) % group_m
    pn = (pid % (GROUP * nn)) // group_m
    rows = pm * BM + tl.arange(0, BM)
    cols = pn * BN + tl.arange(0, BN)
    ks = tl.arange(0, BK)
    acc = tl.zeros((BM, BN), tl.float32)
    for kb in range(tl.cdiv(K, BK)):
        k = kb * BK + ks
        a = tl.load(X + rows[:, None] * K + k[None, :],
                    (rows[:, None] < M) & (k[None, :] < K), 0)
        b = tl.load(W + cols[None, :] * K + k[:, None],
                    (cols[None, :] < N) & (k[:, None] < K), 0)
        acc = tl.dot(a, b, acc)
    tl.store(Y + rows[:, None] * N + cols[None, :], acc.to(Y.dtype.element_ty),
             (rows[:, None] < M) & (cols[None, :] < N))


def kernel(*, x, weight, out=None):
    m, k = x.shape
    n = weight.shape[0]
    if out is None:
        out = torch.empty((m, n), dtype=x.dtype, device=x.device)
    c = _CFG
    grid = (tr.cdiv(m, c["bm"]) * tr.cdiv(n, c["bn"]),)
    _gemm[grid](x, weight, out, m, n, k, c["bm"], c["bn"], c["bk"],
                c["group"], num_warps=c["warps"], num_stages=c["stages"])
    return out
