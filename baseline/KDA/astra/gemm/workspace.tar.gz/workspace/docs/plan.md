# Executable plan

1. Record environment and original reference timing. Build sequential evaluation/logging helpers outside `solution/`.
2. Implement candidate c001: Triton BF16 tiled GEMM, FP32 accumulator, 128x128x64 blocks, four warps, grouped tile order. Validate with the official evaluator and record its frozen sources and result.
3. Profile c001 on the default workload using unique full/source NCU run directories. Extract metrics with `ncu_report`; distinguish SM90 data from the skill's SM100 examples.
4. Tune one candidate at a time. Every candidate has a parent, configuration, exact source snapshot, validation outcome, median latency, and explicit promotion/rejection decision. Failed builds remain recorded. Use the same evaluator for promotions.
5. Implement TMA/persistent scheduling, then explicit WGMMA pipelines if the measured limits justify them. Compare shape, pipeline, scheduling, and store variants. Profile the leaders when new bottlenecks arise.
6. Continue experiments until 2026-09-05 22:26:19 UTC. Track the unchanged deadline during all experiments; stop new launches that jeopardize final validation.
7. Restore the fastest passing `runs/LABEL/solution/` into `solution/`. Run a unique `--mode full` verdict by 22:31:19.295852 UTC. Verify the restored sources, summarize evidence in `REPORT.md`, and leave the workspace ready for the outer runner. Do not push.

Use the exact evaluator commands in `docs/draft.md`. The final candidate must contain only custom compute, must not mutate inputs or retain output values, and must return the exact output shape and dtype. No model delegation.
