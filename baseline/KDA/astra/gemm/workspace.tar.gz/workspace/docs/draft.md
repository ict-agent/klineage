# GEMM optimization draft

Deadline: 2026-09-05 22:31:19.295852 UTC. Final restoration starts at 22:26:19 UTC. The original twelve-hour budget includes all work and is never reset.

Contract: contiguous BF16 `x[4096,4096]`, `weight[4096,4096]`; return BF16 `x @ weight.T` with shape `[4096,4096]`. Inputs are keyword arguments. Preserve input contents, support fresh values at reused addresses, and accumulate in FP32. Fixed tolerance: rtol=0.02, atol=0.02.

Initial solution calls the PyTorch reference. Replace it with custom GPU code. Python is limited to allocation, compilation, views, and launches. No prebuilt compute operators or timing shortcuts. Target: H100 PCIe, SM90, 114 SMs, 80 GiB, 50 MiB L2.

Validation uses the unchanged evaluator, seeds 17/43/101 plus timing and address-reuse checks. Candidate ranking uses median CUPTI latency with cold L2, 10 warmups, 50 repeats, 3 trials.

Directions, in order:
1. Establish a correct Triton tiled BF16 GEMM and profile its compute, memory, and scheduling limits.
2. Tune tile dimensions, pipeline stages, warp count, and tile order; test persistent scheduling and TMA descriptors.
3. Use profiling evidence to implement explicit Hopper TMA/WGMMA pipelines in CUDA/PTX or CuTe DSL if compiler control limits throughput. Explore warp specialization and output-store overlap.
4. Recheck leading candidates under the official timer; preserve every failed experiment.

Risks: FP32 accumulation correctness near zero; shared-memory capacity; register pressure; pipeline synchronization; tail waves on 114 SMs; cold-L2 memory traffic; clock variability; JIT/build overhead. Compile artifacts and package versions must remain reproducible.

Evidence: `candidates.jsonl` holds parent links and promotion decisions, `benchmark.csv` holds measurements, `runs/LABEL/solution/` holds exact sources, and `profile/` holds NCU reports plus analysis. Promote only passing candidates with lower measured median latency.

Commands (each evaluation uses a unique LABEL):
```
/usr/bin/python /workspace/klineage/baseline/evaluate.py --problem gemm --reference /workspace/klineage/agent-workspace/baselines/KDA/astra/gemm/reference.py --solution solution --output runs/LABEL.json
/usr/bin/python /workspace/klineage/baseline/evaluate.py --problem gemm --reference /workspace/klineage/agent-workspace/baselines/KDA/astra/gemm/reference.py --solution solution --mode reference --output runs/reference.json
```

At 22:26:19 UTC, restore the fastest passing frozen solution, run the same command with `--mode full`, and write `REPORT.md` with winning latency, speedup, techniques, failures, dependencies, and limits.
