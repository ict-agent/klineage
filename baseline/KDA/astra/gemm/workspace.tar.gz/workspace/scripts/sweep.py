"""Sequential official evaluations of a specified configuration list."""

import argparse
import datetime as dt
import json
from pathlib import Path

from eval_candidate import ROOT, FINAL_START, evaluate


def main():
    p = argparse.ArgumentParser()
    p.add_argument("configs", type=Path)
    p.add_argument("--prefix", required=True)
    p.add_argument("--parent", required=True)
    args = p.parse_args()
    configs = json.loads(args.configs.read_text())
    for i, config in enumerate(configs):
        if dt.datetime.now(dt.timezone.utc) >= FINAL_START - dt.timedelta(minutes=2):
            print("Stopping for final restoration", flush=True)
            break
        label = f"{args.prefix}_{i:03d}"
        if (ROOT / "runs" / f"{label}.json").exists():
            continue
        (ROOT / "solution/config.json").write_text(json.dumps(config) + "\n")
        evaluate(label, args.parent, f"Sequential sweep {args.configs.name}", timeout=180)


if __name__ == "__main__":
    main()
