"""Run the immutable evaluator and record every candidate decision."""

import argparse
import csv
import datetime as dt
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
EVALUATOR = "/workspace/klineage/baseline/evaluate.py"
FINAL_START = dt.datetime.fromisoformat("2026-09-05T22:26:19+00:00")


def evaluate(label, parent, note, mode="candidate", timeout=600):
    output = ROOT / "runs" / f"{label}.json"
    if output.exists() or output.with_suffix("").exists():
        raise ValueError(f"Label already exists: {label}")
    config_path = ROOT / "solution/config.json"
    config = json.loads(config_path.read_text()) if config_path.exists() else {}
    cmd = ["/usr/bin/python", EVALUATOR, "--problem", "gemm", "--reference",
           str(ROOT / "reference.py"), "--solution", str(ROOT / "solution"),
           "--output", str(output), "--mode", mode]
    start = time.monotonic()
    error = None
    with output.with_suffix(".log").open("w") as log:
        try:
            process = subprocess.run(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                                     timeout=timeout)
            code = process.returncode
        except subprocess.TimeoutExpired:
            error = f"Evaluation exceeded {timeout}s"
            code = -1
    result = json.loads(output.read_text()) if output.exists() else {
        "status": "failed", "error": error or f"Process exited {code}"}
    if not output.exists():
        output.write_text(json.dumps(result, indent=2) + "\n")
    median = result.get("candidate", {}).get("median_ms")
    passed = result["status"] == "passed"
    best_path = ROOT / "best.json"
    best = json.loads(best_path.read_text()) if best_path.exists() else None
    promote = passed and (best is None or median < best["median_ms"])
    decision = "promoted" if promote else ("rejected_slower" if passed else "rejected_failed")
    record = dict(label=label, parent=parent, status=result["status"], median_ms=median,
                  decision=decision, note=note, config=config,
                  timestamp=dt.datetime.now(dt.timezone.utc).isoformat(),
                  elapsed_s=time.monotonic()-start, output=str(output.relative_to(ROOT)),
                  error=result.get("error"))
    with (ROOT / "candidates.jsonl").open("a") as f:
        f.write(json.dumps(record) + "\n")
    csv_path = ROOT / "benchmark.csv"
    new = not csv_path.exists()
    with csv_path.open("a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(record))
        if new:
            writer.writeheader()
        writer.writerow(record)
    if promote:
        best_path.write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record), flush=True)
    return record


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("label")
    p.add_argument("--parent", default="reference")
    p.add_argument("--note", required=True)
    p.add_argument("--mode", default="candidate")
    p.add_argument("--timeout", type=int, default=600)
    args = p.parse_args()
    evaluate(args.label, args.parent, args.note, args.mode, args.timeout)
